/**
 * mini-figma — локальный запуск без интернета.
 *
 * Приложение собрано в статические файлы и не обращается в сеть.
 * Этот скрипт поднимает крошечный HTTP-сервер только на 127.0.0.1,
 * чтобы браузер мог загрузить ES-модули (из file:// они блокируются),
 * и открывает страницу. Зависимостей нет — только Node.js.
 */
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const ROOT = fileURLToPath(new URL('.', import.meta.url));
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.json': 'application/json',
  '.ico': 'image/x-icon',
};

function openBrowser(url) {
  const opts = { detached: true, stdio: 'ignore' };
  try {
    if (process.platform === 'win32') spawn('cmd', ['/c', 'start', '', url], opts).unref();
    else if (process.platform === 'darwin') spawn('open', [url], opts).unref();
    else spawn('xdg-open', [url], opts).unref();
  } catch {
    /* если открыть не удалось — адрес напечатан ниже */
  }
}

const server = createServer(async (req, res) => {
  let file = '';
  try {
    const rel = normalize(decodeURIComponent(new URL(req.url, 'http://localhost').pathname))
      .replace(/^(\.\.[/\\])+/, '')
      .replace(/^[/\\]+/, '');
    file = join(ROOT, rel || 'index.html');
    if (!file.startsWith(ROOT)) throw new Error('forbidden');
    const body = await readFile(file);
    res.writeHead(200, { 'content-type': MIME[extname(file).toLowerCase()] ?? 'application/octet-stream' });
    res.end(body);
  } catch {
    // SPA-фолбэк: любой неизвестный путь отдаёт index.html
    try {
      const body = await readFile(join(ROOT, 'index.html'));
      res.writeHead(200, { 'content-type': MIME['.html'] });
      res.end(body);
    } catch {
      res.writeHead(404).end('not found');
    }
  }
});

server.listen(0, '127.0.0.1', () => {
  const { port } = server.address();
  const url = `http://127.0.0.1:${port}/`;
  console.log('mini-figma запущен: ' + url);
  console.log('Чтобы остановить — закройте это окно (Ctrl+C).');
  openBrowser(url);
});
