@echo off
rem NOTE: this file must stay ASCII-only (cmd.exe reads it byte by byte).
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install it from https://nodejs.org and run this file again.
  pause
  exit /b 1
)

node server.mjs
