#!/bin/sh
# mini-figma — запуск без интернета (нужен только Node.js)
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js не найден. Установите его с https://nodejs.org и запустите снова."
  exit 1
fi

node server.mjs
